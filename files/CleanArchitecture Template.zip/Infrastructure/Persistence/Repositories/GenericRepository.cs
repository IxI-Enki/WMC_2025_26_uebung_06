using Application.Contracts.Repositories;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Infrastructure.Persistence.Repositories;

/// <summary>
/// Generische Repository-Implementierung f�r CRUD-Operationen.
/// Nutzt EF Core DbSet<T> f�r Datenzugriffe.
/// </summary>
public class GenericRepository<T>(AppDbContext dbContext) : IGenericRepository<T> where T : class, IBaseEntity
{
    protected AppDbContext DbContext { get; } = dbContext;
    protected DbSet<T> Set { get; } = dbContext.Set<T>();

    /// <summary>
    /// Holt eine Entit�t per Prim�rschl�ssel.
    /// </summary>
    public virtual async Task<T?> GetByIdAsync(int id, CancellationToken ct = default)
        => await Set.FindAsync([id], ct);

    /// <summary>
    /// Holt alle Entit�ten (optional gefiltert und sortiert). NoTracking f�r read-only.
    /// </summary>
    public virtual async Task<IReadOnlyCollection<T>> GetAllAsync(
        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
        Expression<Func<T, bool>>? filter = null,
        CancellationToken ct = default)
    {
        IQueryable<T> query = Set.AsNoTracking();
        if (filter is not null)
            query = query.Where(filter);
        if (orderBy is not null)
            query = orderBy(query);
        return await query.ToListAsync(ct);
    }

    /// <summary>
    /// F�gt eine neue Entit�t hinzu (noch nicht gespeichert).
    /// </summary>
    public virtual async Task AddAsync(T entity, CancellationToken ct = default)
        => await Set.AddAsync(entity, ct);

    /// <summary>
    /// F�gt mehrere neue Entit�ten hinzu (noch nicht gespeichert).
    /// </summary>
    public virtual async Task AddRangeAsync(IEnumerable<T> entities, CancellationToken ct = default)
        => await Set.AddRangeAsync(entities, ct);

    /// <summary>
    /// Markiert eine Entit�t als ge�ndert.
    /// </summary>
    public virtual void Update(T entity) => Set.Update(entity);

    /// <summary>
    /// Entfernt eine Entit�t.
    /// </summary>
    public virtual void Remove(T entity) => Set.Remove(entity);

    /// <summary>
    /// Entfernt mehrere Entit�ten.
    /// </summary>
    public virtual void RemoveRange(IEnumerable<T> entities) => Set.RemoveRange(entities);
}

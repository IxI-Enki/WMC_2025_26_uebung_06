namespace Application.Features.Dtos;

/// <summary>
/// Daten�bertragungsobjekt (DTO) f�r Messungen in der API-Antwort.
/// Als Referenztyp (record class), um Nullability sauber zu erzwingen.
/// </summary>
public sealed record GetMeasurementDto(int Id, int SensorId, double Value, DateTime Timestamp);
